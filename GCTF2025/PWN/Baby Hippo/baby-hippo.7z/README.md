# Instruction

Create a flag at /flag for testing. 

`echo 'flag{fake_flag} > /flag `

Run your script locally before go to instance.

